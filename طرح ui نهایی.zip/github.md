repo: sajjadshadloo/Notepad
branch: master

## Last sync

date: 2026-09-25T14:57:33Z

### Updated in this project

- Read the Cloudflare Mini App (README, app.css, schema).
- New Notepad Plus Mini App.dc.html: Today, Notes, Editor, Tasks, Calendar with hour timeline, quick capture, task/note sheets, sync + conflict.

## Screen map

| Project screen | Repo files |
|---|---|
| Notepad Plus — Current UI.dc.html · main window | ui/main_window.py, ui/styles.py, ui/document_tab.py, ui/editor.py, ui/markdown_highlighter.py |
| Notepad Plus — Current UI.dc.html · sidebar + calendar | ui/sidebar.py, ui/calendar_panel.py, core/jalali.py, core/daily_notes.py |
| Notepad Plus — Current UI.dc.html · My Tasks | ui/today_view.py, core/tasks.py |
| Notepad Plus — Current UI.dc.html · Go to File | ui/quick_open.py, core/quick_open.py |
| Notepad Plus — Current UI.dc.html · Settings | ui/settings_dialog.py, core/settings_manager.py |
| Notepad Plus — Current UI.dc.html · Find and Replace | ui/main_window.py (FindReplaceDialog) |
| Notepad Plus — Redesign.dc.html · all surfaces | UI-BRIEF.md, ui/styles.py (token names), ui/today_view.py, ui/sidebar.py, core/tasks.py |
| Notepad Plus v4.dc.html · home (folders, cards, today column) | ui/top_bar.py, ui/notes_board.py, ui/note_cards.py, ui/today_rail.py, ui/calendar_panel.py |
| Notepad Plus v4.dc.html · editor + links panel | ui/editor.py, ui/document_tabs.py, KNOWLEDGE-WORKSPACE-PROPOSAL.md |
| Notepad Plus v4.dc.html · my tasks, calendar, detail | ui/today_view.py, ui/task_rows.py, core/tasks.py |
| Notepad Plus v4.dc.html · palette, settings | ui/quick_open.py, ui/settings_dialog.py, ui/styles.py |
| Notepad Plus Mini App.dc.html · all mobile screens | cloudflare/README.md, cloudflare/public/app.css, cloudflare/schema.sql, core/tasks.py |

## Sync history

### Previous sync

date: 2026-09-25T13:37:45Z

### Updated in this project

- Re-read v4.2 (home + editor, today rail, note cards, sync, knowledge-workspace proposal).
- New full redesign Notepad Plus v4.dc.html: icon rail, folder sidebar, card/list toggle, today column with Jalali calendar.
- Editor with links/backlinks panel, My Tasks list + month view with detail pane, Ctrl+K palette, settings.

### Previous sync

date: 2026-08-26T10:12:00Z

### Updated in this project

- Recreated the current v3.6.0 interface (main window, My Tasks, Go to File, Find & Replace, Settings) from the real Qt stylesheet tokens.
- Proposed a redesign as an interactive prototype: dark/light, three accent palettes, command palette, focus mode, today progress.
- Rebuilt My Tasks in three modes (grouped list, today/upcoming, day timeline) with a task detail pane.
- Format bar, status bar and sidebar restructured per the weaknesses listed in UI-BRIEF.md.
